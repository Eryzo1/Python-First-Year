class Carousel:
    def __init__(self) -> None:
        pass
